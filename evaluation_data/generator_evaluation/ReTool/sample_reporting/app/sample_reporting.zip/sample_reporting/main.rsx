<App>
  <Include src="./src/eba_demo_ir_dept.rsx" />
  <Include src="./src/eba_demo_ir_dept_form.rsx" />
  <Include src="./src/eba_demo_ir_emp.rsx" />
  <Include src="./src/eba_demo_ir_emp_form.rsx" />
</App>
