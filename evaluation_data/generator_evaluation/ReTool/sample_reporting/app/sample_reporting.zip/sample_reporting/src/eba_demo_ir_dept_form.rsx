<Screen
  id="eba_demo_ir_dept_form"
  _customShortcuts={[]}
  _hashParams={[]}
  _order={0}
  _searchParams={[]}
  browserTitle={null}
  title={null}
  urlSlug={null}
  uuid="0f856d37-7a99-48eb-ba23-aee0f3db4e9d"
>
  <Frame
    id="$form1"
    enableFullBleed={false}
    isHiddenOnDesktop={false}
    isHiddenOnMobile={false}
    padding="8px 12px"
    sticky={null}
    type="main"
  >
    <TextInput
      id="in_b80bb"
      label="Id"
      placeholder="Enter Id"
    />
    <TextInput
      id="in_1bca6"
      label="Deptno"
      placeholder="Enter Deptno"
    />
    <TextInput
      id="in_7dec7"
      label="Dname"
      placeholder="Enter Dname"
    />
    <TextInput
      id="in_ce04b"
      label="Loc"
      placeholder="Enter Loc"
    />
    <Button
      id="eba_demo_ir_dept_save"
      text="Save"
      colorScheme="green"
    />
    <Button
      id="eba_demo_ir_dept_cancel"
      text="Cancel"
      colorScheme="gray"
    />
  </Frame>
</Screen>
