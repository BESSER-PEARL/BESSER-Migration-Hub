<Screen
  id="eba_demo_ir_emp_form"
  _customShortcuts={[]}
  _hashParams={[]}
  _order={1}
  _searchParams={[]}
  browserTitle={null}
  title={null}
  urlSlug={null}
  uuid="d6424e1e-efd5-49ec-bd86-02cce304796b"
>
  <Frame
    id="$form2"
    enableFullBleed={false}
    isHiddenOnDesktop={false}
    isHiddenOnMobile={false}
    padding="8px 12px"
    sticky={null}
    type="main"
  >
    <TextInput
      id="in_b80bb"
      label="Id"
      placeholder="Enter Id"
    />
    <TextInput
      id="in_8f920"
      label="Comm"
      placeholder="Enter Comm"
    />
    <TextInput
      id="in_1bca6"
      label="Deptno"
      placeholder="Enter Deptno"
    />
    <TextInput
      id="in_b1981"
      label="Empno"
      placeholder="Enter Empno"
    />
    <TextInput
      id="in_d016e"
      label="Ename"
      placeholder="Enter Ename"
    />
    <TextInput
      id="in_3132d"
      label="Hiredate"
      placeholder="Enter Hiredate"
    />
    <TextInput
      id="in_9dddd"
      label="Job"
      placeholder="Enter Job"
    />
    <TextInput
      id="in_7794f"
      label="Sal"
      placeholder="Enter Sal"
    />
    <TextInput
      id="in_ac155"
      label="Ebademoiremp Mgr Id"
      placeholder="Enter Ebademoiremp Mgr Id"
    />
    <Button
      id="eba_demo_ir_emp_save"
      text="Save"
      colorScheme="green"
    />
    <Button
      id="eba_demo_ir_emp_cancel"
      text="Cancel"
      colorScheme="gray"
    />
  </Frame>
</Screen>
