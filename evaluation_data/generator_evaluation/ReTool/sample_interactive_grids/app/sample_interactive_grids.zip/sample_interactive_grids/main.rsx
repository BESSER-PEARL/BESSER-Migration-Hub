<App>
  <Include src="./src/eba_demo_ig_people.rsx" />
  <Include src="./src/eba_demo_ig_people_form.rsx" />
  <Include src="./src/eba_demo_ig_emp.rsx" />
  <Include src="./src/eba_demo_ig_emp_form.rsx" />
  <Include src="./src/eba_demo_ig_dept.rsx" />
  <Include src="./src/eba_demo_ig_dept_form.rsx" />
</App>
