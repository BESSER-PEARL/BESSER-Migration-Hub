<Screen
  id="eba_demo_ig_people_form"
  _customShortcuts={[]}
  _hashParams={[]}
  _order={0}
  _searchParams={[]}
  browserTitle={null}
  title={null}
  urlSlug={null}
  uuid="b3555523-ca12-42be-8715-9ef526c4e0ef"
>
  <Frame
    id="$form1"
    enableFullBleed={false}
    isHiddenOnDesktop={false}
    isHiddenOnMobile={false}
    padding="8px 12px"
    sticky={null}
    type="main"
  >
    <TextInput
      id="in_b80bb"
      label="Id"
      placeholder="Enter Id"
    />
    <TextInput
      id="in_c4ef3"
      label="Category"
      placeholder="Enter Category"
    />
    <TextInput
      id="in_e909c"
      label="Country"
      placeholder="Enter Country"
    />
    <TextInput
      id="in_3f77e"
      label="Flex1"
      placeholder="Enter Flex1"
    />
    <TextInput
      id="in_5cb95"
      label="Flex2"
      placeholder="Enter Flex2"
    />
    <TextInput
      id="in_4b4f2"
      label="Flex3"
      placeholder="Enter Flex3"
    />
    <TextInput
      id="in_9c8b0"
      label="From Yr"
      placeholder="Enter From Yr"
    />
    <TextInput
      id="in_cc90f"
      label="Gender"
      placeholder="Enter Gender"
    />
    <TextInput
      id="in_b80bb"
      label="Id"
      placeholder="Enter Id"
    />
    <TextInput
      id="in_2a304"
      label="Link"
      placeholder="Enter Link"
    />
    <TextInput
      id="in_b0689"
      label="Name"
      placeholder="Enter Name"
    />
    <TextInput
      id="in_2c550"
      label="Rating"
      placeholder="Enter Rating"
    />
    <TextInput
      id="in_a7069"
      label="To Yr"
      placeholder="Enter To Yr"
    />
    <Button
      id="eba_demo_ig_people_save"
      text="Save"
      colorScheme="green"
    />
    <Button
      id="eba_demo_ig_people_cancel"
      text="Cancel"
      colorScheme="gray"
    />
  </Frame>
</Screen>
