<Screen
  id="eba_demo_ig_emp_form"
  _customShortcuts={[]}
  _hashParams={[]}
  _order={1}
  _searchParams={[]}
  browserTitle={null}
  title={null}
  urlSlug={null}
  uuid="79501a1f-7ebb-45bf-80b0-ae3c7b9ee5fd"
>
  <Frame
    id="$form2"
    enableFullBleed={false}
    isHiddenOnDesktop={false}
    isHiddenOnMobile={false}
    padding="8px 12px"
    sticky={null}
    type="main"
  >
    <TextInput
      id="in_b80bb"
      label="Id"
      placeholder="Enter Id"
    />
    <TextInput
      id="in_8f920"
      label="Comm"
      placeholder="Enter Comm"
    />
    <TextInput
      id="in_b1981"
      label="Empno"
      placeholder="Enter Empno"
    />
    <TextInput
      id="in_d016e"
      label="Ename"
      placeholder="Enter Ename"
    />
    <TextInput
      id="in_3f77e"
      label="Flex1"
      placeholder="Enter Flex1"
    />
    <TextInput
      id="in_5cb95"
      label="Flex2"
      placeholder="Enter Flex2"
    />
    <TextInput
      id="in_4b4f2"
      label="Flex3"
      placeholder="Enter Flex3"
    />
    <TextInput
      id="in_e677c"
      label="Flex4"
      placeholder="Enter Flex4"
    />
    <TextInput
      id="in_3132d"
      label="Hiredate"
      placeholder="Enter Hiredate"
    />
    <TextInput
      id="in_9dddd"
      label="Job"
      placeholder="Enter Job"
    />
    <TextInput
      id="in_4358b"
      label="Notes"
      placeholder="Enter Notes"
    />
    <TextInput
      id="in_b83ed"
      label="Onleave"
      placeholder="Enter Onleave"
    />
    <TextInput
      id="in_2c550"
      label="Rating"
      placeholder="Enter Rating"
    />
    <TextInput
      id="in_7794f"
      label="Sal"
      placeholder="Enter Sal"
    />
    <TextInput
      id="in_ffea6"
      label="Ebademoigemp Mgr Id"
      placeholder="Enter Ebademoigemp Mgr Id"
    />
    <TextInput
      id="in_3f9e4"
      label="Ebademoigdept Id"
      placeholder="Enter Ebademoigdept Id"
    />
    <Button
      id="eba_demo_ig_emp_save"
      text="Save"
      colorScheme="green"
    />
    <Button
      id="eba_demo_ig_emp_cancel"
      text="Cancel"
      colorScheme="gray"
    />
  </Frame>
</Screen>
