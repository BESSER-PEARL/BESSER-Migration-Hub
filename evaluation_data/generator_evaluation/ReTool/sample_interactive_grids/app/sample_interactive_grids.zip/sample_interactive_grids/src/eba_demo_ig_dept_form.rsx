<Screen
  id="eba_demo_ig_dept_form"
  _customShortcuts={[]}
  _hashParams={[]}
  _order={2}
  _searchParams={[]}
  browserTitle={null}
  title={null}
  urlSlug={null}
  uuid="7a7f8a15-23f6-4f7b-a7cf-ad15fe778609"
>
  <Frame
    id="$form3"
    enableFullBleed={false}
    isHiddenOnDesktop={false}
    isHiddenOnMobile={false}
    padding="8px 12px"
    sticky={null}
    type="main"
  >
    <TextInput
      id="in_b80bb"
      label="Id"
      placeholder="Enter Id"
    />
    <TextInput
      id="in_1bca6"
      label="Deptno"
      placeholder="Enter Deptno"
    />
    <TextInput
      id="in_7dec7"
      label="Dname"
      placeholder="Enter Dname"
    />
    <TextInput
      id="in_ce04b"
      label="Loc"
      placeholder="Enter Loc"
    />
    <TextInput
      id="in_4358b"
      label="Notes"
      placeholder="Enter Notes"
    />
    <Button
      id="eba_demo_ig_dept_save"
      text="Save"
      colorScheme="green"
    />
    <Button
      id="eba_demo_ig_dept_cancel"
      text="Cancel"
      colorScheme="gray"
    />
  </Frame>
</Screen>
