<Screen
  id="eba_demo_md_projects_form"
  _customShortcuts={[]}
  _hashParams={[]}
  _order={5}
  _searchParams={[]}
  browserTitle={null}
  title={null}
  urlSlug={null}
  uuid="ffb9bcb2-d8e5-4b2b-b251-0214aea4589a"
>
  <Frame
    id="$form6"
    enableFullBleed={false}
    isHiddenOnDesktop={false}
    isHiddenOnMobile={false}
    padding="8px 12px"
    sticky={null}
    type="main"
  >
    <TextInput
      id="in_b80bb"
      label="Id"
      placeholder="Enter Id"
    />
    <TextInput
      id="in_73390"
      label="Completed Date"
      placeholder="Enter Completed Date"
    />
    <TextInput
      id="in_e2fa5"
      label="Created"
      placeholder="Enter Created"
    />
    <TextInput
      id="in_dad46"
      label="Created By"
      placeholder="Enter Created By"
    />
    <TextInput
      id="in_67daf"
      label="Description"
      placeholder="Enter Description"
    />
    <TextInput
      id="in_b80bb"
      label="Id"
      placeholder="Enter Id"
    />
    <TextInput
      id="in_b0689"
      label="Name"
      placeholder="Enter Name"
    />
    <TextInput
      id="in_0f81d"
      label="Updated"
      placeholder="Enter Updated"
    />
    <TextInput
      id="in_ee4f5"
      label="Updated By"
      placeholder="Enter Updated By"
    />
    <TextInput
      id="in_2e1be"
      label="Ebademomdteammembers Id"
      placeholder="Enter Ebademomdteammembers Id"
    />
    <TextInput
      id="in_a85a0"
      label="Ebademomdstatus Id"
      placeholder="Enter Ebademomdstatus Id"
    />
    <Button
      id="btn_cancel_4"
      text="Cancel"
      colorScheme="gray"
    />
    <Button
      id="btn_add_2"
      text="Create"
      colorScheme="blue"
    />
    <Button
      id="btn_save_3"
      text="Save"
      colorScheme="green"
    />
    <Button
      id="btn_cancel_2"
      text="Cancel"
      colorScheme="gray"
    />
    <Button
      id="btn_add_1"
      text="Create"
      colorScheme="blue"
    />
    <Button
      id="btn_save_3"
      text="Save"
      colorScheme="green"
    />
    <Button
      id="btn_cancel_7"
      text="Cancel"
      colorScheme="gray"
    />
    <Button
      id="btn_cancel_5"
      text="Add_Comment"
      colorScheme="gray"
    />
    <Button
      id="btn_cancel_2"
      text="Get_Previous_Rowid"
      colorScheme="gray"
    />
    <Button
      id="btn_cancel_1"
      text="Get_Next_Rowid"
      colorScheme="gray"
    />
    <Button
      id="btn_add_4"
      text="Create"
      colorScheme="blue"
    />
    <Button
      id="btn_save_6"
      text="Save"
      colorScheme="green"
    />
    <Button
      id="btn_delete_1"
      text="Delete"
      colorScheme="red"
    />
    <Button
      id="btn_delete_4"
      text="Delete"
      colorScheme="red"
    />
    <Button
      id="btn_delete_3"
      text="Delete"
      colorScheme="red"
    />
  </Frame>
</Screen>
