<Screen
  id="eba_demo_md_status_form"
  _customShortcuts={[]}
  _hashParams={[]}
  _order={7}
  _searchParams={[]}
  browserTitle={null}
  title={null}
  urlSlug={null}
  uuid="887d31b0-4c46-4395-b860-3d89b4b5260b"
>
  <Frame
    id="$form8"
    enableFullBleed={false}
    isHiddenOnDesktop={false}
    isHiddenOnMobile={false}
    padding="8px 12px"
    sticky={null}
    type="main"
  >
    <TextInput
      id="in_b80bb"
      label="Id"
      placeholder="Enter Id"
    />
    <TextInput
      id="in_6865a"
      label="Cd"
      placeholder="Enter Cd"
    />
    <TextInput
      id="in_e2fa5"
      label="Created"
      placeholder="Enter Created"
    />
    <TextInput
      id="in_dad46"
      label="Created By"
      placeholder="Enter Created By"
    />
    <TextInput
      id="in_67daf"
      label="Description"
      placeholder="Enter Description"
    />
    <TextInput
      id="in_010c8"
      label="Display Order"
      placeholder="Enter Display Order"
    />
    <TextInput
      id="in_0f81d"
      label="Updated"
      placeholder="Enter Updated"
    />
    <TextInput
      id="in_ee4f5"
      label="Updated By"
      placeholder="Enter Updated By"
    />
    <Button
      id="eba_demo_md_status_save"
      text="Save"
      colorScheme="green"
    />
    <Button
      id="eba_demo_md_status_cancel"
      text="Cancel"
      colorScheme="gray"
    />
  </Frame>
</Screen>
