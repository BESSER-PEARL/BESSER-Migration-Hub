<Screen
  id="eba_demo_md_team_members_form"
  _customShortcuts={[]}
  _hashParams={[]}
  _order={6}
  _searchParams={[]}
  browserTitle={null}
  title={null}
  urlSlug={null}
  uuid="666eccb7-6101-4598-90e0-3f1e84aabaf1"
>
  <Frame
    id="$form7"
    enableFullBleed={false}
    isHiddenOnDesktop={false}
    isHiddenOnMobile={false}
    padding="8px 12px"
    sticky={null}
    type="main"
  >
    <TextInput
      id="in_b80bb"
      label="Id"
      placeholder="Enter Id"
    />
    <TextInput
      id="in_e2fa5"
      label="Created"
      placeholder="Enter Created"
    />
    <TextInput
      id="in_dad46"
      label="Created By"
      placeholder="Enter Created By"
    />
    <TextInput
      id="in_0c83f"
      label="Email"
      placeholder="Enter Email"
    />
    <TextInput
      id="in_73037"
      label="Full Name"
      placeholder="Enter Full Name"
    />
    <TextInput
      id="in_b80bb"
      label="Id"
      placeholder="Enter Id"
    />
    <TextInput
      id="in_7d974"
      label="Profile"
      placeholder="Enter Profile"
    />
    <TextInput
      id="in_0f81d"
      label="Updated"
      placeholder="Enter Updated"
    />
    <TextInput
      id="in_ee4f5"
      label="Updated By"
      placeholder="Enter Updated By"
    />
    <TextInput
      id="in_14c4b"
      label="Username"
      placeholder="Enter Username"
    />
    <Button
      id="eba_demo_md_team_members_save"
      text="Save"
      colorScheme="green"
    />
    <Button
      id="eba_demo_md_team_members_cancel"
      text="Cancel"
      colorScheme="gray"
    />
  </Frame>
</Screen>
