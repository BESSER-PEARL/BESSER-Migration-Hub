<Screen
  id="eba_demo_md_milestones_form"
  _customShortcuts={[]}
  _hashParams={[]}
  _order={4}
  _searchParams={[]}
  browserTitle={null}
  title={null}
  urlSlug={null}
  uuid="4b332796-111f-420c-940e-b5ba0074322f"
>
  <Frame
    id="$form5"
    enableFullBleed={false}
    isHiddenOnDesktop={false}
    isHiddenOnMobile={false}
    padding="8px 12px"
    sticky={null}
    type="main"
  >
    <TextInput
      id="in_b80bb"
      label="Id"
      placeholder="Enter Id"
    />
    <TextInput
      id="in_e2fa5"
      label="Created"
      placeholder="Enter Created"
    />
    <TextInput
      id="in_dad46"
      label="Created By"
      placeholder="Enter Created By"
    />
    <TextInput
      id="in_67daf"
      label="Description"
      placeholder="Enter Description"
    />
    <TextInput
      id="in_c96c6"
      label="Due Date"
      placeholder="Enter Due Date"
    />
    <TextInput
      id="in_b80bb"
      label="Id"
      placeholder="Enter Id"
    />
    <TextInput
      id="in_b0689"
      label="Name"
      placeholder="Enter Name"
    />
    <TextInput
      id="in_0f81d"
      label="Updated"
      placeholder="Enter Updated"
    />
    <TextInput
      id="in_ee4f5"
      label="Updated By"
      placeholder="Enter Updated By"
    />
    <TextInput
      id="in_648a9"
      label="Ebademomdprojects Id"
      placeholder="Enter Ebademomdprojects Id"
    />
    <Button
      id="btn_cancel_1"
      text="Cancel"
      colorScheme="gray"
    />
    <Button
      id="btn_add_3"
      text="Create"
      colorScheme="blue"
    />
    <Button
      id="btn_save_4"
      text="Save"
      colorScheme="green"
    />
    <Button
      id="btn_cancel_3"
      text="Cancel"
      colorScheme="gray"
    />
    <Button
      id="btn_add_1"
      text="Create"
      colorScheme="blue"
    />
    <Button
      id="btn_save_2"
      text="Save"
      colorScheme="green"
    />
    <Button
      id="btn_delete_2"
      text="Delete"
      colorScheme="red"
    />
    <Button
      id="btn_delete_4"
      text="Delete"
      colorScheme="red"
    />
  </Frame>
</Screen>
