<Screen
  id="eba_demo_md_tasks_form"
  _customShortcuts={[]}
  _hashParams={[]}
  _order={3}
  _searchParams={[]}
  browserTitle={null}
  title={null}
  urlSlug={null}
  uuid="fd585610-0513-4ad3-8832-05a9184f7724"
>
  <Frame
    id="$form4"
    enableFullBleed={false}
    isHiddenOnDesktop={false}
    isHiddenOnMobile={false}
    padding="8px 12px"
    sticky={null}
    type="main"
  >
    <TextInput
      id="in_b80bb"
      label="Id"
      placeholder="Enter Id"
    />
    <TextInput
      id="in_e2fa5"
      label="Created"
      placeholder="Enter Created"
    />
    <TextInput
      id="in_dad46"
      label="Created By"
      placeholder="Enter Created By"
    />
    <TextInput
      id="in_67daf"
      label="Description"
      placeholder="Enter Description"
    />
    <TextInput
      id="in_90e8d"
      label="End Date"
      placeholder="Enter End Date"
    />
    <TextInput
      id="in_b80bb"
      label="Id"
      placeholder="Enter Id"
    />
    <TextInput
      id="in_592b9"
      label="Is Complete Yn"
      placeholder="Enter Is Complete Yn"
    />
    <TextInput
      id="in_b0689"
      label="Name"
      placeholder="Enter Name"
    />
    <TextInput
      id="in_eadbb"
      label="Start Date"
      placeholder="Enter Start Date"
    />
    <TextInput
      id="in_0f81d"
      label="Updated"
      placeholder="Enter Updated"
    />
    <TextInput
      id="in_ee4f5"
      label="Updated By"
      placeholder="Enter Updated By"
    />
    <TextInput
      id="in_a039f"
      label="Ebademomdmilestones Id"
      placeholder="Enter Ebademomdmilestones Id"
    />
    <TextInput
      id="in_2e1be"
      label="Ebademomdteammembers Id"
      placeholder="Enter Ebademomdteammembers Id"
    />
    <TextInput
      id="in_648a9"
      label="Ebademomdprojects Id"
      placeholder="Enter Ebademomdprojects Id"
    />
    <Button
      id="btn_cancel_2"
      text="Cancel"
      colorScheme="gray"
    />
    <Button
      id="btn_save_1"
      text="Save"
      colorScheme="green"
    />
    <Button
      id="btn_add_4"
      text="Create"
      colorScheme="blue"
    />
    <Button
      id="btn_cancel_4"
      text="Cancel"
      colorScheme="gray"
    />
    <Button
      id="btn_add_1"
      text="Create"
      colorScheme="blue"
    />
    <Button
      id="btn_save_2"
      text="Save"
      colorScheme="green"
    />
    <Button
      id="btn_delete_3"
      text="Delete"
      colorScheme="red"
    />
    <Button
      id="btn_delete_3"
      text="Delete"
      colorScheme="red"
    />
  </Frame>
</Screen>
