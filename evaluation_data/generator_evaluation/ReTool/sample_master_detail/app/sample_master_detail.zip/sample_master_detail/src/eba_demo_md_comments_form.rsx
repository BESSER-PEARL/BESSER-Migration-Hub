<Screen
  id="eba_demo_md_comments_form"
  _customShortcuts={[]}
  _hashParams={[]}
  _order={0}
  _searchParams={[]}
  browserTitle={null}
  title={null}
  urlSlug={null}
  uuid="0e58f8e6-a812-4f4b-b22a-5a9083e5b574"
>
  <Frame
    id="$form1"
    enableFullBleed={false}
    isHiddenOnDesktop={false}
    isHiddenOnMobile={false}
    padding="8px 12px"
    sticky={null}
    type="main"
  >
    <TextInput
      id="in_b80bb"
      label="Id"
      placeholder="Enter Id"
    />
    <TextInput
      id="in_64be6"
      label="Comment Text"
      placeholder="Enter Comment Text"
    />
    <TextInput
      id="in_e2fa5"
      label="Created"
      placeholder="Enter Created"
    />
    <TextInput
      id="in_dad46"
      label="Created By"
      placeholder="Enter Created By"
    />
    <TextInput
      id="in_b80bb"
      label="Id"
      placeholder="Enter Id"
    />
    <TextInput
      id="in_0f81d"
      label="Updated"
      placeholder="Enter Updated"
    />
    <TextInput
      id="in_ee4f5"
      label="Updated By"
      placeholder="Enter Updated By"
    />
    <TextInput
      id="in_648a9"
      label="Ebademomdprojects Id"
      placeholder="Enter Ebademomdprojects Id"
    />
    <Button
      id="btn_cancel_2"
      text="Cancel"
      colorScheme="gray"
    />
    <Button
      id="btn_save_3"
      text="Save"
      colorScheme="green"
    />
    <Button
      id="btn_add_4"
      text="Create"
      colorScheme="blue"
    />
    <Button
      id="btn_cancel_1"
      text="Cancel"
      colorScheme="gray"
    />
    <Button
      id="btn_add_2"
      text="Create"
      colorScheme="blue"
    />
    <Button
      id="btn_save_3"
      text="Save"
      colorScheme="green"
    />
    <Button
      id="btn_delete_1"
      text="Delete"
      colorScheme="red"
    />
    <Button
      id="btn_delete_4"
      text="Delete"
      colorScheme="red"
    />
  </Frame>
</Screen>
