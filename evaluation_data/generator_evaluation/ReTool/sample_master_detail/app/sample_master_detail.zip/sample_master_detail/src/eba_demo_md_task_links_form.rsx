<Screen
  id="eba_demo_md_task_links_form"
  _customShortcuts={[]}
  _hashParams={[]}
  _order={1}
  _searchParams={[]}
  browserTitle={null}
  title={null}
  urlSlug={null}
  uuid="82623e68-d777-47fd-8e6b-5edf44592cd2"
>
  <Frame
    id="$form2"
    enableFullBleed={false}
    isHiddenOnDesktop={false}
    isHiddenOnMobile={false}
    padding="8px 12px"
    sticky={null}
    type="main"
  >
    <TextInput
      id="in_b80bb"
      label="Id"
      placeholder="Enter Id"
    />
    <TextInput
      id="in_6bc0a"
      label="Application Id"
      placeholder="Enter Application Id"
    />
    <TextInput
      id="in_417d8"
      label="Application Page"
      placeholder="Enter Application Page"
    />
    <TextInput
      id="in_e2fa5"
      label="Created"
      placeholder="Enter Created"
    />
    <TextInput
      id="in_dad46"
      label="Created By"
      placeholder="Enter Created By"
    />
    <TextInput
      id="in_67daf"
      label="Description"
      placeholder="Enter Description"
    />
    <TextInput
      id="in_b80bb"
      label="Id"
      placeholder="Enter Id"
    />
    <TextInput
      id="in_f6baf"
      label="Link Type"
      placeholder="Enter Link Type"
    />
    <TextInput
      id="in_0f81d"
      label="Updated"
      placeholder="Enter Updated"
    />
    <TextInput
      id="in_ee4f5"
      label="Updated By"
      placeholder="Enter Updated By"
    />
    <TextInput
      id="in_572d4"
      label="Url"
      placeholder="Enter Url"
    />
    <TextInput
      id="in_edf5e"
      label="Ebademomdtasks Id"
      placeholder="Enter Ebademomdtasks Id"
    />
    <TextInput
      id="in_648a9"
      label="Ebademomdprojects Id"
      placeholder="Enter Ebademomdprojects Id"
    />
    <Button
      id="btn_cancel_4"
      text="Cancel"
      colorScheme="gray"
    />
    <Button
      id="btn_cancel_2"
      text="Add_Link"
      colorScheme="gray"
    />
    <Button
      id="btn_cancel_1"
      text="Add_Todo"
      colorScheme="gray"
    />
    <Button
      id="btn_save_3"
      text="Edit_Task"
      colorScheme="green"
    />
    <Button
      id="btn_cancel_1"
      text="Cancel"
      colorScheme="gray"
    />
    <Button
      id="btn_save_2"
      text="Save"
      colorScheme="green"
    />
    <Button
      id="btn_cancel_1"
      text="Cancel"
      colorScheme="gray"
    />
    <Button
      id="btn_save_3"
      text="Save"
      colorScheme="green"
    />
    <Button
      id="btn_add_4"
      text="Add"
      colorScheme="blue"
    />
    <Button
      id="btn_delete_2"
      text="Delete"
      colorScheme="red"
    />
  </Frame>
</Screen>
