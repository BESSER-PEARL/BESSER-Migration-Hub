<App>
  <Include src="./src/eba_demo_cal_mysessions.rsx" />
  <Include src="./src/eba_demo_cal_mysessions_form.rsx" />
  <Include src="./src/eba_demo_cal_sessions.rsx" />
  <Include src="./src/eba_demo_cal_sessions_form.rsx" />
  <Include src="./src/eba_demo_cal_projects.rsx" />
  <Include src="./src/eba_demo_cal_projects_form.rsx" />
</App>
