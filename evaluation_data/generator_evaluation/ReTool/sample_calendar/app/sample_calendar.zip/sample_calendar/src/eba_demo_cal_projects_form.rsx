<Screen
  id="eba_demo_cal_projects_form"
  _customShortcuts={[]}
  _hashParams={[]}
  _order={2}
  _searchParams={[]}
  browserTitle={null}
  title={null}
  urlSlug={null}
  uuid="eaa4b0f3-6834-4145-b231-61ee153a21be"
>
  <Frame
    id="$form3"
    enableFullBleed={false}
    isHiddenOnDesktop={false}
    isHiddenOnMobile={false}
    padding="8px 12px"
    sticky={null}
    type="main"
  >
    <TextInput
      id="in_b80bb"
      label="Id"
      placeholder="Enter Id"
    />
    <TextInput
      id="in_8fdc8"
      label="Assigned To"
      placeholder="Enter Assigned To"
    />
    <TextInput
      id="in_2f212"
      label="Budget"
      placeholder="Enter Budget"
    />
    <TextInput
      id="in_4e156"
      label="Cost"
      placeholder="Enter Cost"
    />
    <TextInput
      id="in_90e8d"
      label="End Date"
      placeholder="Enter End Date"
    />
    <TextInput
      id="in_b80bb"
      label="Id"
      placeholder="Enter Id"
    />
    <TextInput
      id="in_46f86"
      label="Project"
      placeholder="Enter Project"
    />
    <TextInput
      id="in_d2472"
      label="Row Version Number"
      placeholder="Enter Row Version Number"
    />
    <TextInput
      id="in_eadbb"
      label="Start Date"
      placeholder="Enter Start Date"
    />
    <TextInput
      id="in_9acb4"
      label="Status"
      placeholder="Enter Status"
    />
    <TextInput
      id="in_80899"
      label="Task Name"
      placeholder="Enter Task Name"
    />
    <Button
      id="btn_cancel_3"
      text="Cancel"
      colorScheme="gray"
    />
    <Button
      id="btn_save_1"
      text="Save"
      colorScheme="green"
    />
    <Button
      id="btn_add_2"
      text="Create"
      colorScheme="blue"
    />
    <Button
      id="btn_delete_4"
      text="Delete"
      colorScheme="red"
    />
  </Frame>
</Screen>
