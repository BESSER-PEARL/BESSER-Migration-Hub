<Screen
  id="eba_demo_cal_mysessions_form"
  _customShortcuts={[]}
  _hashParams={[]}
  _order={0}
  _searchParams={[]}
  browserTitle={null}
  title={null}
  urlSlug={null}
  uuid="b768c9c2-6614-44ca-a84d-6e883564fef3"
>
  <Frame
    id="$form1"
    enableFullBleed={false}
    isHiddenOnDesktop={false}
    isHiddenOnMobile={false}
    padding="8px 12px"
    sticky={null}
    type="main"
  >
    <TextInput
      id="in_b80bb"
      label="Id"
      placeholder="Enter Id"
    />
    <TextInput
      id="in_90e8d"
      label="End Date"
      placeholder="Enter End Date"
    />
    <TextInput
      id="in_b80bb"
      label="Id"
      placeholder="Enter Id"
    />
    <TextInput
      id="in_d2472"
      label="Row Version Number"
      placeholder="Enter Row Version Number"
    />
    <TextInput
      id="in_4ea57"
      label="Session Type"
      placeholder="Enter Session Type"
    />
    <TextInput
      id="in_f0dc8"
      label="Speaker"
      placeholder="Enter Speaker"
    />
    <TextInput
      id="in_eadbb"
      label="Start Date"
      placeholder="Enter Start Date"
    />
    <TextInput
      id="in_9acb4"
      label="Status"
      placeholder="Enter Status"
    />
    <TextInput
      id="in_d5d3d"
      label="Title"
      placeholder="Enter Title"
    />
    <Button
      id="eba_demo_cal_mysessions_save"
      text="Save"
      colorScheme="green"
    />
    <Button
      id="eba_demo_cal_mysessions_cancel"
      text="Cancel"
      colorScheme="gray"
    />
  </Frame>
</Screen>
