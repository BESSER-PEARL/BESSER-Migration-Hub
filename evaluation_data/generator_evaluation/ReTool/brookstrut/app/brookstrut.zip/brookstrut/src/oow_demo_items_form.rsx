<Screen
  id="oow_demo_items_form"
  _customShortcuts={[]}
  _hashParams={[]}
  _order={3}
  _searchParams={[]}
  browserTitle={null}
  title={null}
  urlSlug={null}
  uuid="276fdaae-157c-4c88-bfc5-48f521c2692f"
>
  <Frame
    id="$form4"
    enableFullBleed={false}
    isHiddenOnDesktop={false}
    isHiddenOnMobile={false}
    padding="8px 12px"
    sticky={null}
    type="main"
  >
    <TextInput
      id="in_b80bb"
      label="Id"
      placeholder="Enter Id"
    />
    <TextInput
      id="in_b80bb"
      label="Id"
      placeholder="Enter Id"
    />
    <TextInput
      id="in_ffac0"
      label="Item Desc"
      placeholder="Enter Item Desc"
    />
    <TextInput
      id="in_9d030"
      label="Item Name"
      placeholder="Enter Item Name"
    />
    <TextInput
      id="in_7f6bf"
      label="Item Type"
      placeholder="Enter Item Type"
    />
    <TextInput
      id="in_70f97"
      label="Msrp"
      placeholder="Enter Msrp"
    />
    <Button
      id="oow_demo_items_save"
      text="Save"
      colorScheme="green"
    />
    <Button
      id="oow_demo_items_cancel"
      text="Cancel"
      colorScheme="gray"
    />
  </Frame>
</Screen>
