<Screen
  id="oow_demo_store_products_form"
  _customShortcuts={[]}
  _hashParams={[]}
  _order={1}
  _searchParams={[]}
  browserTitle={null}
  title={null}
  urlSlug={null}
  uuid="d1da117f-ab3a-403e-af35-4bd953695f99"
>
  <Frame
    id="$form2"
    enableFullBleed={false}
    isHiddenOnDesktop={false}
    isHiddenOnMobile={false}
    padding="8px 12px"
    sticky={null}
    type="main"
  >
    <TextInput
      id="in_b80bb"
      label="Id"
      placeholder="Enter Id"
    />
    <TextInput
      id="in_aeb26"
      label="Discount Pct"
      placeholder="Enter Discount Pct"
    />
    <TextInput
      id="in_b80bb"
      label="Id"
      placeholder="Enter Id"
    />
    <TextInput
      id="in_8b22a"
      label="Item Price"
      placeholder="Enter Item Price"
    />
    <TextInput
      id="in_9f752"
      label="Sale End Date"
      placeholder="Enter Sale End Date"
    />
    <TextInput
      id="in_2f90f"
      label="Sale Start Date"
      placeholder="Enter Sale Start Date"
    />
    <TextInput
      id="in_416c1"
      label="Oowdemostores Id"
      placeholder="Enter Oowdemostores Id"
    />
    <TextInput
      id="in_31307"
      label="Oowdemoitems Id"
      placeholder="Enter Oowdemoitems Id"
    />
    <Button
      id="btn_cancel_2"
      text="Cancel"
      colorScheme="gray"
    />
    <Button
      id="btn_add_1"
      text="Create"
      colorScheme="blue"
    />
    <Button
      id="btn_save_4"
      text="Save"
      colorScheme="green"
    />
    <Button
      id="btn_cancel_2"
      text="Up"
      colorScheme="gray"
    />
    <Button
      id="btn_cancel_1"
      text="Edit_Store"
      colorScheme="gray"
    />
    <Button
      id="btn_delete_3"
      text="Delete"
      colorScheme="red"
    />
  </Frame>
</Screen>
