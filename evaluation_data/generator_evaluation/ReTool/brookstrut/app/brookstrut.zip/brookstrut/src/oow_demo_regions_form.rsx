<Screen
  id="oow_demo_regions_form"
  _customShortcuts={[]}
  _hashParams={[]}
  _order={4}
  _searchParams={[]}
  browserTitle={null}
  title={null}
  urlSlug={null}
  uuid="d943f742-474b-4813-9f72-1ba697093702"
>
  <Frame
    id="$form5"
    enableFullBleed={false}
    isHiddenOnDesktop={false}
    isHiddenOnMobile={false}
    padding="8px 12px"
    sticky={null}
    type="main"
  >
    <TextInput
      id="in_b80bb"
      label="Id"
      placeholder="Enter Id"
    />
    <TextInput
      id="in_b80bb"
      label="Id"
      placeholder="Enter Id"
    />
    <TextInput
      id="in_6ea85"
      label="Is Default Yn"
      placeholder="Enter Is Default Yn"
    />
    <TextInput
      id="in_7250e"
      label="Region Color"
      placeholder="Enter Region Color"
    />
    <TextInput
      id="in_fa7d1"
      label="Region Lat"
      placeholder="Enter Region Lat"
    />
    <TextInput
      id="in_fa56c"
      label="Region Lng"
      placeholder="Enter Region Lng"
    />
    <TextInput
      id="in_7f119"
      label="Region Name"
      placeholder="Enter Region Name"
    />
    <TextInput
      id="in_b16cc"
      label="Region Zoom"
      placeholder="Enter Region Zoom"
    />
    <Button
      id="btn_cancel_1"
      text="Cancel"
      colorScheme="gray"
    />
    <Button
      id="btn_save_2"
      text="Save"
      colorScheme="green"
    />
    <Button
      id="btn_add_3"
      text="Create"
      colorScheme="blue"
    />
    <Button
      id="btn_delete_4"
      text="Delete"
      colorScheme="red"
    />
  </Frame>
</Screen>
