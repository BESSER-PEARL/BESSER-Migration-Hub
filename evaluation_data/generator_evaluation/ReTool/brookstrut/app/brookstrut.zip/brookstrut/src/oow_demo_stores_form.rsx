<Screen
  id="oow_demo_stores_form"
  _customShortcuts={[]}
  _hashParams={[]}
  _order={2}
  _searchParams={[]}
  browserTitle={null}
  title={null}
  urlSlug={null}
  uuid="a899052c-cef4-46f3-b61e-3dc8d0a65e47"
>
  <Frame
    id="$form3"
    enableFullBleed={false}
    isHiddenOnDesktop={false}
    isHiddenOnMobile={false}
    padding="8px 12px"
    sticky={null}
    type="main"
  >
    <TextInput
      id="in_b80bb"
      label="Id"
      placeholder="Enter Id"
    />
    <TextInput
      id="in_b80bb"
      label="Id"
      placeholder="Enter Id"
    />
    <TextInput
      id="in_0831e"
      label="Store Address"
      placeholder="Enter Store Address"
    />
    <TextInput
      id="in_fca9b"
      label="Store City"
      placeholder="Enter Store City"
    />
    <TextInput
      id="in_95da5"
      label="Store Lat"
      placeholder="Enter Store Lat"
    />
    <TextInput
      id="in_010c2"
      label="Store Lng"
      placeholder="Enter Store Lng"
    />
    <TextInput
      id="in_b7cd1"
      label="Store Name"
      placeholder="Enter Store Name"
    />
    <TextInput
      id="in_745aa"
      label="Store State"
      placeholder="Enter Store State"
    />
    <TextInput
      id="in_21df1"
      label="Store Type"
      placeholder="Enter Store Type"
    />
    <TextInput
      id="in_9d1d5"
      label="Store Zip"
      placeholder="Enter Store Zip"
    />
    <TextInput
      id="in_a4974"
      label="Oowdemoregions Id"
      placeholder="Enter Oowdemoregions Id"
    />
    <Button
      id="oow_demo_stores_save"
      text="Save"
      colorScheme="green"
    />
    <Button
      id="oow_demo_stores_cancel"
      text="Cancel"
      colorScheme="gray"
    />
  </Frame>
</Screen>
