<Screen
  id="oow_demo_sales_history_form"
  _customShortcuts={[]}
  _hashParams={[]}
  _order={0}
  _searchParams={[]}
  browserTitle={null}
  title={null}
  urlSlug={null}
  uuid="07825a63-1199-43c8-8656-5f8646109e19"
>
  <Frame
    id="$form1"
    enableFullBleed={false}
    isHiddenOnDesktop={false}
    isHiddenOnMobile={false}
    padding="8px 12px"
    sticky={null}
    type="main"
  >
    <TextInput
      id="in_b80bb"
      label="Id"
      placeholder="Enter Id"
    />
    <TextInput
      id="in_08096"
      label="Date Of Sale"
      placeholder="Enter Date Of Sale"
    />
    <TextInput
      id="in_b80bb"
      label="Id"
      placeholder="Enter Id"
    />
    <TextInput
      id="in_8b22a"
      label="Item Price"
      placeholder="Enter Item Price"
    />
    <TextInput
      id="in_221d2"
      label="Quantity"
      placeholder="Enter Quantity"
    />
    <TextInput
      id="in_f847d"
      label="Transaction Id"
      placeholder="Enter Transaction Id"
    />
    <TextInput
      id="in_886c7"
      label="Oowdemostoreproducts Id"
      placeholder="Enter Oowdemostoreproducts Id"
    />
    <TextInput
      id="in_416c1"
      label="Oowdemostores Id"
      placeholder="Enter Oowdemostores Id"
    />
    <Button
      id="btn_cancel_3"
      text="Generate_Transaction"
      colorScheme="gray"
    />
    <Button
      id="btn_cancel_2"
      text="Up"
      colorScheme="gray"
    />
    <Button
      id="btn_cancel_1"
      text="Refresh"
      colorScheme="gray"
    />
  </Frame>
</Screen>
