<App>
  <Include src="./src/oow_demo_sales_history.rsx" />
  <Include src="./src/oow_demo_sales_history_form.rsx" />
  <Include src="./src/oow_demo_store_products.rsx" />
  <Include src="./src/oow_demo_store_products_form.rsx" />
  <Include src="./src/oow_demo_stores.rsx" />
  <Include src="./src/oow_demo_stores_form.rsx" />
  <Include src="./src/oow_demo_items.rsx" />
  <Include src="./src/oow_demo_items_form.rsx" />
  <Include src="./src/oow_demo_regions.rsx" />
  <Include src="./src/oow_demo_regions_form.rsx" />
</App>
