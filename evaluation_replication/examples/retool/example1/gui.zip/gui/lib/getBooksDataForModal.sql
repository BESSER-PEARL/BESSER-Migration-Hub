SELECT * FROM books

